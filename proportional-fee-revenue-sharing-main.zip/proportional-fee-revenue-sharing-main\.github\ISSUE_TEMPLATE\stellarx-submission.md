---
name: StellarX Submission
about: Submit Proportional Fee Revenue Sharing
title: "Proportional Fee Revenue Sharing"
labels: stellarx, submission
assignees: ""
---

## Project

Proportional Fee Revenue Sharing

## Idea Number

109

## Summary

Proportional Fee Revenue Sharing gives operators a shared settlement score trail, signed wallet actions, and a Soroban-backed release path that can be audited from dashboard to ledger.

## Stellar Usage

- Stellar testnet
- Soroban contract
- Freighter wallet
- Stellar SDK
- XLM/USDC SAC references
